require('coffee-script/register')
require('./server/server')
