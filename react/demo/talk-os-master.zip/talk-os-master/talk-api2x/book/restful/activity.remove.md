# activity.remove

Remove an activity

## Route
> DELETE /v2/activities/:_id

## Params
| key            | type               | required | description    |

## Request
```json
DELETE /v2/activities/56a87b21b68100820c993f99 HTTP/1.1
```

### Response
```json
{
  "__v": 0,
  "team": "56a87b20b68100820c993f84",
  "target": "56a87b21b68100820c993f97",
  "type": "room",
  "creator": "56a87b20b68100820c993f82",
  "text": "{{__info-create-room}} New room",
  "_id": "56a87b21b68100820c993f99",
  "updatedAt": "2016-01-27T08:09:05.213Z",
  "createdAt": "2016-01-27T08:09:05.212Z",
  "members": [],
  "isPublic": true,
  "_creatorId": "56a87b20b68100820c993f82",
  "_targetId": "56a87b21b68100820c993f97",
  "_teamId": "56a87b20b68100820c993f84",
  "id": "56a87b21b68100820c993f99"
}
```
