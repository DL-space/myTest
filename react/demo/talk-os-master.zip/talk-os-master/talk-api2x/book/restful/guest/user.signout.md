## guest/user.signout

### summary
Sign out

### method
POST

### route
> /api/users/signout

### params
<table>
  <thead>
    <tr>
      <th>key</th>
      <th>type</th>
      <th>required</th>
      <th>description</th>
    </tr>
  </thead>
</table>

### request
```
POST /api/users/signout HTTP/1.1
```

### response
```json
{
  "ok": 1
}
```
