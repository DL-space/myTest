## favorite.search

### summary
Search for the favorites

### method
POST

### route
> /v2/favorites/search

[message.search](message.search.html)
