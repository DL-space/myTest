# Login Process

<img src="login.png" alt="login" width="300px">

* User sign in with teambition email/password
* If user have joined a team at last visit, talk should redirect to the main webpage of this team.
* Else user will enter a page to choose or create a team, these teams are from the organizations or other integration applications.
* User login in the team, and go on.
