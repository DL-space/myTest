# Embed in project

![embed](/doc/diagram/embed.png)
