# Weibo

## Notifications

- mention: @我  ['{{__info-weibo-new-comment}}']
- comment: 评论  ['{{__info-weibo-new-mention}}']
- repost: 转发  ['{{__info-weibo-new-repost}}']
