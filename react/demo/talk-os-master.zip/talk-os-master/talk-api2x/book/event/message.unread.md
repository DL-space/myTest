## message:unread

### summary
unread message number of each room/chat

### response
```json
{
    "_teamId": "538d7a8eb0064cd263ea24cd",
    "unread": {
      "538d7a8eb0064cd263ea24cd": 0
    },
    "_latestReadMessageId": {
      // targetId: messageId
      "538d7a8eb0064cd263ea24cd": "538d7a8eb0064cd263ea24ce"
    }
}
```
