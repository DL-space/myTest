## room:update

### summary
updated infomation of room

### channel
team

### response
```json
{
    "__v": 0,
    "topic": "New Topic",
    "creator": "536c834d26faf71918b774ea",
    "team": "536c99d0460682621f7ea6e5",
    "_id": "536c9d223888f40b20b7e278",
    "_memberIds": [
      "5513a5a94ff269411d71734a"
    ],
    "updatedAt": "2014-05-09T09:17:22.959Z",
    "createdAt": "2014-05-09T09:17:22.959Z",
    "_creatorId": "536c834d26faf71918b774ea",
    "_teamId": "536c99d0460682621f7ea6e5",
    "id": "536c9d223888f40b20b7e278"
}
```
