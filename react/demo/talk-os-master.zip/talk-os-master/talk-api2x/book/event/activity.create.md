# activity:create

Newest activity

## Response

```json
{
  "__v": 0,
  "team": "56a87b20b68100820c993f84",
  "target": {
    "_id": "56a87b21b68100820c993f97",
    "email": "newroom.r3b96654023@mail.jianliao.com",
    "topic": "New room",
    "py": "new room",
    "pinyin": "new room",
    "creator": "56a87b20b68100820c993f82",
    "team": "56a87b20b68100820c993f84",
    "__v": 0,
    "updatedAt": "2016-01-27T08:09:05.169Z",
    "createdAt": "2016-01-27T08:09:05.169Z",
    "memberCount": 1,
    "pys": [
      "new room"
    ],
    "pinyins": [
      "new room"
    ],
    "isGuestVisible": true,
    "color": "blue",
    "isPrivate": false,
    "isArchived": false,
    "isGeneral": false,
    "popRate": 3,
    "_creatorId": "56a87b20b68100820c993f82",
    "_teamId": "56a87b20b68100820c993f84",
    "id": "56a87b21b68100820c993f97"
  },
  "type": "room",
  "creator": {
    "_id": "56a87b20b68100820c993f82",
    "name": "dajiangyou1",
    "py": "dajiangyou1",
    "pinyin": "dajiangyou1",
    "emailForLogin": "user1@teambition.com",
    "emailDomain": "teambition.com",
    "__v": 0,
    "unions": [],
    "updatedAt": "2016-01-27T08:09:04.099Z",
    "createdAt": "2016-01-27T08:09:04.098Z",
    "isGuest": false,
    "isRobot": false,
    "pys": [
      "dajiangyou1"
    ],
    "pinyins": [
      "dajiangyou1"
    ],
    "from": "register",
    "avatarUrl": "null",
    "id": "56a87b20b68100820c993f82",
    "email": "user1@teambition.com"
  },
  "text": "{{__info-create-room}} New room",
  "_id": "56a87b21b68100820c993f99",
  "updatedAt": "2016-01-27T08:09:05.213Z",
  "createdAt": "2016-01-27T08:09:05.212Z",
  "members": [],
  "isPublic": true,
  "_creatorId": "56a87b20b68100820c993f82",
  "_targetId": "56a87b21b68100820c993f97",
  "_teamId": "56a87b20b68100820c993f84",
  "id": "56a87b21b68100820c993f99"
}
```
