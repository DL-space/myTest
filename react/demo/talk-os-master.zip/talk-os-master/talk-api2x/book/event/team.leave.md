## team:leave

### summary
the member leaved team

### response
```
{
    "_userId": "536c834d26faf71918b774ea",
    "_teamId": "536c834d26faf71918b774ed"
}
```
