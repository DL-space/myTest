## message:remove

### summary
removed message id

### response
```
{
    "_id": "538d7d6d255600da6286865b",
    "_roomId": "538d7d6d255600da6286865b",
    "_teamId": "538d7d6d255600da6286865b"
}
```
