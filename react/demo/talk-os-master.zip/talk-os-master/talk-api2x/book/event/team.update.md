## team:update

### summary
new team infomation

### channel
team

### response
```
{
    "__v": 0,
    "name": "new team",
    "creator": "536c834d26faf71918b774ea",
    "createdAt": "2014-05-09T09:03:12.838Z",
    "_id": "536c99d0460682621f7ea6e5",
    "updatedAt": "2014-05-09T09:03:12.838Z",
    "_creatorId": "536c834d26faf71918b774ea",
    "id": "536c99d0460682621f7ea6e5"
}
```
