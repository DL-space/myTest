## room.members.prefs:update

### summary
updated prefs of the other members of this room

### channel
team

### response
```json
{
  "isMute": true,
  "alias": "ALICE",
  "_userId": "5513a5a94ff269411d71733c",
  "_roomId": "5513a5a94ff269411d71734a",
  "_teamId": "5513a5a94ff269411d71733e"
}
```
