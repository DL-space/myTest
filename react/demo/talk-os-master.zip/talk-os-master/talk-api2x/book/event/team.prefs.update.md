## team.prefs:update

### summary
updated preference of team

### channel
user

### response
```json
{
  "isMute": true,
  "alias": "ALICE",
  "_teamId": "5513d3457931dc303563f374",
  "_userId": "5513d3457931dc303563f372"
}
```
