## team.members.prefs:update

### summary
updated prefs of the other members of this team

### channel
team

### response
```json
{
  "isMute": true,
  "alias": "ALICE",
  "_teamId": "5513d3457931dc303563f374",
  "_userId": "5513d3457931dc303563f372"
}
```
