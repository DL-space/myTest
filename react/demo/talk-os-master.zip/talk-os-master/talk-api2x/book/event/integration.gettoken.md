## integration:gettoken

### summary
broadcast the token of integration

### response
```json
{
    "token": "fasdfasdfasdfasdfasdfasd",
    "showname": "小恶魔"
}
```
