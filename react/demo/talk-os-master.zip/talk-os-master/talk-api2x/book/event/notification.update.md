# notification:update

Newest notification

## Response

```json
{
  "__v": 0,
  "text": "message 1",
  "creator": {
    "_id": "560b9ed68f361cc04f2547a8",
    "name": "dajiangyou2",
    "py": "dajiangyou2",
    "pinyin": "dajiangyou2",
    "emailForLogin": "user2@teambition.com",
    "emailDomain": "teambition.com",
    "phoneForLogin": "13388888882",
    "__v": 0,
    "unions": [],
    "updatedAt": "2015-09-30T08:35:34.389Z",
    "createdAt": "2015-09-30T08:35:34.389Z",
    "isGuest": false,
    "isRobot": false,
    "pys": [
      "dajiangyou2"
    ],
    "pinyins": [
      "dajiangyou2"
    ],
    "from": "register",
    "avatarUrl": "null",
    "id": "560b9ed68f361cc04f2547a8",
    "mobile": "13388888882",
    "email": "user2@teambition.com"
  },
  "team": "560b9ed78f361cc04f2547a9",
  "user": "560b9ed68f361cc04f2547a7",
  "target": {
    "_id": "560b9ed68f361cc04f2547a8",
    "name": "dajiangyou2",
    "py": "dajiangyou2",
    "pinyin": "dajiangyou2",
    "emailForLogin": "user2@teambition.com",
    "emailDomain": "teambition.com",
    "phoneForLogin": "13388888882",
    "__v": 0,
    "unions": [],
    "updatedAt": "2015-09-30T08:35:34.389Z",
    "createdAt": "2015-09-30T08:35:34.389Z",
    "isGuest": false,
    "isRobot": false,
    "pys": [
      "dajiangyou2"
    ],
    "pinyins": [
      "dajiangyou2"
    ],
    "from": "register",
    "avatarUrl": "null",
    "id": "560b9ed68f361cc04f2547a8",
    "mobile": "13388888882",
    "email": "user2@teambition.com"
  },
  "type": "dms",
  "_id": "560b9ed78f361cc04f2547dc",
  "updatedAt": "2015-09-30T08:35:35.510Z",
  "createdAt": "2015-09-30T08:35:35.479Z",
  "unreadNum": 1,
  "_creatorId": "560b9ed68f361cc04f2547a8",
  "_targetId": "560b9ed68f361cc04f2547a8",
  "_teamId": "560b9ed78f361cc04f2547a9",
  "_userId": "560b9ed68f361cc04f2547a7",
  "id": "560b9ed78f361cc04f2547dc"
}
```
