## file:update

### summary
updated infomation of file

### response
```
{
  "__v": 0,
  "_id": "53993403c3bc0c47175f4689",
  "createdAt": "2014-06-12T05:00:51.645Z",
  "creator": {
    "_id": "540041f1b5708f6722038a4f",
    "__v": 0,
    "avatarUrl": "https://secure.gravatar.com/avatar/1fcf44dc4b534d34425e95159887e588?s=200&r=pg&d=retro",
    "email": "jingxin@teambition.com",
    "mobile": "",
    "name": "许晶鑫",
    "sourceId": "53fec0869117faad54be56b3",
    "isRobot": false,
    "from": "register",
    "updatedAt": "2014-10-27T05:21:20.632Z",
    "createdAt": "2014-08-29T09:03:45.614Z",
    "source": "teambition",
    "pinyins": [
      "xujingxin",
      "hujingxin"
    ],
    "pinyin": "xujingxin",
    "id": "540041f1b5708f6722038a4f"
  },
  "fileKey": "2dda216c6095750ec4840925a14ebad1",
  "fileName": "2.png",
  "fileType": "png",
  "message": {
    "category": "file",
    "creator": "538d7a8eb0064cd263ea24cd",
    "room": "538d7d6d255600da6286865b",
    "team": "538d7a8eb0064cd263ea24ca",
    "createdAt": "2014-06-12T05:00:51.654Z",
    "updatedAt": "2014-06-12T05:00:51.654Z",
    "file": "53993403c3bc0c47175f4689",
    "_id": "53993403c3bc0c47175f468a",
    "__v": 0,
    "_teamId": "538d7a8eb0064cd263ea24ca",
    "_roomId": "538d7d6d255600da6286865b",
    "_creatorId": "538d7a8eb0064cd263ea24cd",
    "id": "53993403c3bc0c47175f468a"
  },
  "team": "538d7a8eb0064cd263ea24ca",
  "updatedAt": "2014-06-12T05:00:51.645Z",
  "_messageId": "53993403c3bc0c47175f468a",
  "_creatorId": "538d7a8eb0064cd263ea24cd",
  "_teamId": "538d7a8eb0064cd263ea24ca",
  "thumbnailUrl": "http://striker.project.ci/thumbnail/2d/da/216c6095750ec4840925a14ebad1.png/w/500/h/500",
  "downloadUrl": "http://striker.project.ci/uploads/2d/da/216c6095750ec4840925a14ebad1.png?download=2.png&e=1402552983&sign=8af4d8fc95330570180d923d9d7192a8a18c8faf:ywIkIAN4goXBHyXhi5-AYkwrbww=",
  "id": "53993403c3bc0c47175f4689"
  },
  {
  "__v": 0,
  "_id": "53993403c3bc0c47175f4689",
  "createdAt": "2014-06-12T05:00:51.645Z",
  "creator": {
    "_id": "540041f1b5708f6722038a4f",
    "__v": 0,
    "avatarUrl": "https://secure.gravatar.com/avatar/1fcf44dc4b534d34425e95159887e588?s=200&r=pg&d=retro",
    "email": "jingxin@teambition.com",
    "mobile": "",
    "name": "许晶鑫",
    "sourceId": "53fec0869117faad54be56b3",
    "isRobot": false,
    "from": "register",
    "updatedAt": "2014-10-27T05:21:20.632Z",
    "createdAt": "2014-08-29T09:03:45.614Z",
    "source": "teambition",
    "pinyins": [
      "xujingxin",
      "hujingxin"
    ],
    "pinyin": "xujingxin",
    "id": "540041f1b5708f6722038a4f"
  },
  "fileKey": "2dda216c6095750ec4840925a14ebad1",
  "fileName": "2.png",
  "fileType": "png",
  "message": {
    "category": "file",
    "creator": "538d7a8eb0064cd263ea24cd",
    "room": "538d7d6d255600da6286865b",
    "team": "538d7a8eb0064cd263ea24ca",
    "createdAt": "2014-06-12T05:00:51.654Z",
    "updatedAt": "2014-06-12T05:00:51.654Z",
    "file": "53993403c3bc0c47175f4689",
    "_id": "53993403c3bc0c47175f468a",
    "__v": 0,
    "_teamId": "538d7a8eb0064cd263ea24ca",
    "_roomId": "538d7d6d255600da6286865b",
    "_creatorId": "538d7a8eb0064cd263ea24cd",
    "id": "53993403c3bc0c47175f468a"
  },
  "team": "538d7a8eb0064cd263ea24ca",
  "updatedAt": "2014-06-12T05:00:51.645Z",
  "_messageId": "53993403c3bc0c47175f468a",
  "_creatorId": "538d7a8eb0064cd263ea24cd",
  "_teamId": "538d7a8eb0064cd263ea24ca",
  "thumbnailUrl": "http://striker.project.ci/thumbnail/2d/da/216c6095750ec4840925a14ebad1.png/w/500/h/500",
  "downloadUrl": "http://striker.project.ci/uploads/2d/da/216c6095750ec4840925a14ebad1.png?download=2.png&e=1402552983&sign=8af4d8fc95330570180d923d9d7192a8a18c8faf:ywIkIAN4goXBHyXhi5-AYkwrbww=",
  "id": "53993403c3bc0c47175f4689"
}
```
