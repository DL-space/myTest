## member:update

### summary
member of the team

### response
```
{
    "_userId": "536c834d26faf71918b774ea",
    "_teamId": "536c834d26faf71918b774ed",
    "role": "admin"
}
```
