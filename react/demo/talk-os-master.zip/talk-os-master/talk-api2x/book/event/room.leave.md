## room:leave

### summary
the member leaved room

### response
```json
{
    "_userId": "536c834d26faf71918b774ea",
    "_roomId": "536c834d26faf71918b774ed",
    "_teamId": "536c834d26faf71918b774e2"
}
```
