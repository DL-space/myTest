## team:join

### summary
new member of the team

### response
```json
{
  "__v": 0,
  "sourceId": "53febfcb2c52a0b243c594bc",
  "email": "lurenjia@teambition.com",
  "name": "lurenjia",
  "pinyin": "lurenjia",
  "_id": "54c09be1c6174f9f605b277e",
  "globalRole": "user",
  "isRobot": false,
  "pinyins": [
    "lurenjia"
  ],
  "from": "invitation",
  "updatedAt": "2015-01-22T06:42:41.723Z",
  "createdAt": "2015-01-22T06:42:41.723Z",
  "source": "teambition",
  "avatarUrl": "https://dn-st.qbox.me/user_default_avatars/4.png",
  "id": "54c09be1c6174f9f605b277e",
  "_teamId": "54c09be1c6174f9f605b2764",
  "team": {
    "_id": "54c09be1c6174f9f605b2764",
    "name": "team1",
    "creator": "54c09be1c6174f9f605b2762",
    "__v": 0,
    "updatedAt": "2015-01-22T06:42:41.628Z",
    "createdAt": "2015-01-22T06:42:41.628Z",
    "nonJoinable": false,
    "color": "cyan",
    "_creatorId": "54c09be1c6174f9f605b2762",
    "id": "54c09be1c6174f9f605b2764"
  }
}
```
