* 分离测试中的 Restful API 响应部分和推送部分
