# 解绑第三方账号

> POST /v1/union/unbind/:refer

| 参数            | 类型               | 是否必须  | 描述  |
| -------------- | ------------------ | -------- | ------------ |

## 响应

```json
{
  "_id": "55ee97aa778848f0eb7137ef",
  "__v": 0,
  "updatedAt": "2015-09-08T08:09:14.649Z",
  "createdAt": "2015-09-08T08:09:14.649Z",
  "login": "teambition",
  "wasNew": false,
  "id": "55ee97aa778848f0eb7137ef"
}
```
