# larrycms
感谢大家的点赞支持和热心关注，原计划是想将这套LarryCMS后台所有界面完成后当作一个完整的案例分享给大家，由于时间和工作原因，加上个人能力和经验有限，可能代码写的不太完美，我个人特别喜欢贤心出品的layui这个前端框架，给工作带来很大的便捷，小弟在此抛砖引玉，将模版预览部分静态html分享 放在github上，一起交流layui的使用经验，期待更多好的作品出现<br>
github地址：https://github.com/larryqin/larrycms<br>
layui后台交流群：493153642<br>
项目文件中common/layui 文件夹下需要自行在 www.layui.com 官方下载layui框架文件<br>
