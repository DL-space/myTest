# 百度百家

> 这是我在学习完vue之后的一个练习项目，结构简单，十分适合新手学习。

### 首页截图
<center>
<img src="https://daoket.github.io/baijia/eg1.jpg" width='375' height='667'/>
</center>
<center>
<img src="https://daoket.github.io/baijia/eg2.jpg" width='375' height='667'/>
</center>

## 创建步骤

``` bash
1. git clone https://github.com/daoket/baidubaijia.git

# install dependencies
2. npm install

# serve with hot reload at localhost:8080
3. npm run dev

# build for production with minification
4. npm run build

# build for production and view the bundle analyzer report
5. npm run build --report
```

## 参考
> - [vue官网](http://cn.vuejs.org/)
> - [vue-loader](https://router.vuejs.org/)
